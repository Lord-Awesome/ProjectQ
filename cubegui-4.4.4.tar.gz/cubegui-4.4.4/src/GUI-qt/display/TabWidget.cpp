/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/



#include "config.h"

#include <QLabel>
#include <QComboBox>
#include <QVBoxLayout>
#include <QAction>
#include "TabWidget.h"
#include "ValueWidget.h"
#include "TreeView.h"
#include "Globals.h"
#include "TabInterface.h"
#include "Constants.h"
#include "PluginManager.h"
#include "CubePlugin.h"
#include <QMouseEvent>

using namespace cubegui;
using namespace cubepluginapi;

TabWidget::TabWidget( DisplayType type )
{
    mainTabWidget     = 0;
    this->displayType = type;
}
/**
 * @brief TabWidget::initialize is called after a cube file has been loaded
 * @param order
 */
void
TabWidget::initialize( const QList<DisplayType>& order )
{
    valueModus  = ABSOLUTE_VALUES;
    valueWidget = new ValueWidget();
    valueCombo  = new QComboBox();
    valueCombo->setWhatsThis( "Each tree view has its own value mode combo, a drop-down menu above the tree, where it is possible to change the way the severity values are displayed.\n\nThe default value mode is the Absolute value mode. In this mode, as explained below, the severity values from the Cube file are displayed. However, sometimes these values may be hard to interpret, and in such cases other value modes can be applied. Basically, there are three categories of additional value modes.\n\n- The first category presents all severities in the tree as percentage of a reference value. The reference value can be the absolute value of a selected or a root node from the same tree or in one of the trees on the left-hand-side. For example, in the Own root percent value mode the severity values are presented as percentage of the own root's (inclusive) severity value. This way you can see how the severities are distributed within the tree. The value modes 2-8 below fall into this category.\n\nAll nodes of trees on the left-hand-side of the metric tree have undefined values. (Basically, we could compute values for them, but it would sum up the severities over all metrics, that have different meanings and usually even different units, and thus those values would not have much expressiveness.) Since we cannot compute percentage values based on undefined reference values, such value modes are not supported. For example, if the call tree is on the left-hand-side, and the metric tree is in the middle, then the metric tree does not offer the Call root percent mode.\n\n- The second category is available for system trees only, and shows the distribution of the values within hierarchy levels. E.g., the Peer percent value mode displays the severities as percentage of the maximal value on the same hierarchy depth. The value modes 9-10 fall into this category.\n\n- Finally, the External percent value mode relates the severity values to severities from another external Cube file.\n\nDepending on the type and position of the tree, the following value modes may be available:\n\n1) Absolute (default)\n2) Metric root percent\n3) Metric selection percent\n4) Call root percent\n5) Call selection percent\n6) System root percent\n7) System selection percent\n8) Own root percent\n9) Peer percent\n10) Peer distribution\n11) External percent" );

    if ( displayType == SYSTEM ) // create nested tab widgets for system tab
    {
        mainTabWidget = new QTabWidget;
        mainTabWidget->setMovable( true );
        mainTabWidget->setTabPosition( QTabWidget::East );
        mainTabWidget->setDocumentMode( true );
        QVBoxLayout* mainLayout = new QVBoxLayout();
        mainLayout->setMargin( 0 );
        mainLayout->setSpacing( 0 );
        mainLayout->addWidget( mainTabWidget );
        setLayout( mainLayout );
        createSystemTabWidget( "System View" );
        createSystemTabWidget( "Other", OTHER_PLUGIN_TAB );
        systemTabChanged( 0 );
        connect( mainTabWidget, SIGNAL( currentChanged( int ) ), this, SLOT( systemTabChanged( int ) ) );
    }
    else // metric and call tabs
    {
        DetachableTabWidget* tabWidget = new DetachableTabWidget( this );
        tabWidgetList.append( tabWidget );
        mainTabWidget = tabWidget;
        mainTabWidget->setUsesScrollButtons( true );
        mainTabWidget->setIconSize( QSize( 20, 20 ) );

        QVBoxLayout* layout = new QVBoxLayout();
        setLayout( layout );
        layout->setMargin( LAYOUT_MARGIN );
        layout->setSpacing( LAYOUT_SPACING );
        layout->addWidget( valueCombo );
        layout->addWidget( mainTabWidget );
        layout->addWidget( valueWidget );
        connect( mainTabWidget, SIGNAL( currentChanged( int ) ), this, SLOT( onCurrentChanged() ) );
    }

    setOrder( order );
}

/** called when cube file is closed; deletes all widget contents */
void
TabWidget::cubeClosed()
{
    delete mainTabWidget;
    delete layout();
    mainTabWidget = 0;
    valueCombo    = 0;
    valueWidget   = 0;

    systemTabs.clear();
    tabWidgetList.clear();
    pluginTabHash.clear();
    treeHash.clear();
    toolbars.clear();
    pluginWidgets.clear();
    order.clear();
    changeInfo.clear();
}

/**
 * slot which is called if right side system tab widget is activated
 */
void
TabWidget::systemTabChanged( int index )
{
    QWidget*             widget    = mainTabWidget->widget( index );
    DetachableTabWidget* systemTab = systemTabs.value( widget );
    if ( systemTab != widget ) // widget contains value combobox...
    {
        // insert contents only if tab becomes active, because valueCombo and valueWidget are used in multiple tabs
        // but a widget can only be added to one parent widget
        QWidget* oldParent = valueCombo->parentWidget();
        if ( oldParent )
        {
            oldParent->layout()->removeWidget( valueCombo );
            oldParent->layout()->removeWidget( valueWidget );
        }

        delete widget->layout();
        QLayout* layout = new QVBoxLayout();
        widget->setLayout( layout );
        layout->setMargin( LAYOUT_MARGIN );
        layout->setSpacing( LAYOUT_SPACING );
        layout->addWidget( valueCombo );
        layout->addWidget( systemTabs.value( widget ) );
        layout->addWidget( valueWidget );
        systemTabs.value( widget )->setVisible( true );
    }
    onCurrentChanged(); // notify child tab widget
}


/** creates tab widget which will be child of the system tab main widget
 * @returns tabID of the created tab widget which can be used in TabWidget::addPluginTab
 */
int
TabWidget::createSystemTabWidget( const QString& label, TabType tabType  )
{
    assert( this->getType() == SYSTEM );
    DetachableTabWidget* tabWidget = new DetachableTabWidget();
    tabWidgetList.append( tabWidget );

    if ( tabType == OTHER_PLUGIN_TAB )
    {
        mainTabWidget->addTab( tabWidget, label );
        systemTabs.insert( tabWidget, tabWidget );
    }
    else // put tab widget into a container widget later ( with valueCombo and valueWidget )
    {
        QWidget* container = new QWidget();
        mainTabWidget->addTab( container, label );
        systemTabs.insert( container, tabWidget );
        // move new tab below the default tab (default tab is on first position)
#if QT_VERSION >= 0x050000
        mainTabWidget->tabBar()->moveTab( tabWidgetList.size() - 1, 1 );
#endif
    }
    connect( tabWidget, SIGNAL( currentChanged( int ) ), this, SLOT( onCurrentChanged() ) );
    connect( tabWidget, SIGNAL( activated( TabInterface* ) ), this, SLOT( setActiveTab( TabInterface* ) ) ); // detach signal

    return tabWidgetList.size() - 1;                                                                         // ID of the Tab Widget == listindex
}

void
TabWidget::setOrder( const QList<DisplayType>& order )
{
    this->order = order;
    updateValueCombo();
}

void
TabWidget::addPluginTab( TabInterface* tc, const QString& pluginName, int tabWidgetID )
{
    this->addTab( tc, true, tabWidgetID );
    tabWidgetList.value( tabWidgetID )->setDetachable( tc->widget(), pluginName );
    pluginWidgets.append( tc->widget() );
}

void
TabWidget::removePluginTab( TabInterface* tc )
{
    DetachableTabWidget* tabWidget = getParentTabWidget( tc );
    tabWidget->removeTabInterface( tc );
}

void
TabWidget::detachTab( TabInterface* ti )
{
    DetachableTabWidget* foundTabWidget = 0;
    foreach( DetachableTabWidget * tabWidget, tabWidgetList )
    {
        for ( int tabIndex = 0; tabIndex < tabWidget->count(); tabIndex++ )
        {
            QWidget* toCheck = tabWidget->widget( tabIndex );
            if ( toCheck == ti->widget() )
            {
                foundTabWidget = tabWidget;
                foundTabWidget->detachTab( tabIndex );
                setActiveTab( ti );
                break;
            }
        }
    }
}

void
TabWidget::toFront( const QString& label )
{
    foreach( TabInterface * tc, pluginTabHash.keys() )
    {
        if ( tc->label().contains( label ) )
        {
            toFront( tc );
            break;
        }
    }
}

void
TabWidget::toFront( TabInterface* tc )
{
    DetachableTabWidget* tabWidget = getParentTabWidget( tc );
    int                  index     = tabWidget->indexOf( tc->widget() );

    if ( index >= 0  ) // tab is not detached
    {
        tabWidget->setCurrentIndex( index );

        if ( displayType == SYSTEM ) // activate outer tab widget
        {
            for ( int i = 0; i < mainTabWidget->count(); i++ )
            {
                if ( mainTabWidget->widget( i ) == tabWidget )
                {
                    mainTabWidget->setCurrentIndex( i );
                }
            }
        }
    }
    else
    {
        QMainWindow* window = dynamic_cast<CloseableMainWindow*>( tc->widget()->parent() );
        if ( window )
        {
            window->raise();
            window->showNormal();
        }
    }
}

int
TabWidget::addTab( TabInterface* tc, bool detachable, int tabWidgetID )
{
    pluginTabHash.insert( tc, tabWidgetID );

    DetachableTabWidget* tabWidget = 0;
    if ( displayType != SYSTEM )
    {
        tabWidget = dynamic_cast<DetachableTabWidget*> ( mainTabWidget );
    }
    else
    {
        tabWidget = tabWidgetList.value( tabWidgetID );
        if ( !tabWidget )
        {
            qDebug() << "tried to add system plugin tab to non existent tab widget";
            return -1;
        }
    }

    int index = tabWidget->indexOf( tc->widget() );
    if ( index >= 0 )
    {
        tabWidget->setCurrentIndex( index );
        return index;
    }

    tabWidget->addTabInterface( tc->widget(), tc );
    if ( detachable )
    {
        tabWidget->setDetachable( tc->widget() );
    }

    return tabWidget->addTab( tc->widget(), tc->icon(), tc->label() );
}

int
TabWidget::addTreeTab( TreeView* treeView )
{
    treeHash.insert( treeView->widget(), treeView );
    return addTab( treeView );
}

TreeView*
TabWidget::getActiveTreeView()
{
    TreeView* treeView = 0;
    if ( treeHash.size() == 1 ) // only one tree in this tab
    {
        treeView = treeHash.values().first();
    }
    else // CALLTREE of CALLFLAT
    {
        treeView = dynamic_cast<TreeView*> ( currentTabInterface() );
    }
    return treeView;
}

/** Returns currenly active tab or null, if no tab is visible.
 *  In case of System tab, the active tab of the active tab bar is returned.
 */
TabInterface*
TabWidget::currentTabInterface() const
{
    DetachableTabWidget* tabWidget = 0;

    if ( !mainTabWidget )
    {
        return NULL;
    }
    else if ( displayType == SYSTEM ) // for system tab: get active tab widget
    {
        tabWidget = systemTabs.value( mainTabWidget->currentWidget() );
    }
    else
    {
        tabWidget = dynamic_cast<DetachableTabWidget*> ( mainTabWidget );
    }
    return tabWidget && tabWidget->count() > 0 ? tabWidget->getTabInterface( tabWidget->currentWidget() ) : 0;
}

/**************** get methods ******************/

// return the current value modus, see constants.h for the ValueModus type
//
ValueModus
TabWidget::getValueModus()
{
    return valueModus;
}

ValueWidget*
TabWidget::getValueWidget()
{
    return valueWidget;
}

DisplayType
TabWidget::getType() const
{
    return displayType;
}

/**********************************/
/** updates the value widget with current tree values */
void
TabWidget::updateValueWidget()
{
    double minValue;
    double maxValue;
    double selectedValue;
    double minAbsValue;
    double maxAbsValue;
    double absValue;
    double mean;
    double varianceSqrt;
    Tree*  tree                    = getActiveTreeView()->getTree();
    bool   userDefinedMinMaxValues = tree->hasUserDefinedMinMaxValues();
    bool   wasOk                   = tree->getStatisticValues( minValue, maxValue, selectedValue,
                                                               minAbsValue, maxAbsValue, absValue,
                                                               mean, varianceSqrt );

    TreeItem* item    = tree->getLastSelection();
    bool      intType = item ? item->isIntegerType() : false;

    valueWidget->clear();
    if ( !wasOk )
    {
        valueWidget->update( minValue, maxValue, intType, userDefinedMinMaxValues, mean, varianceSqrt );
    }
    else if ( tree->getValueModus() == ABSOLUTE_VALUES )
    {
        valueWidget->update( minValue, maxValue, absValue, intType, userDefinedMinMaxValues, mean, varianceSqrt );
    }
    else
    {
        valueWidget->update( minValue, maxValue, selectedValue,
                             minAbsValue, maxAbsValue, absValue,
                             intType, userDefinedMinMaxValues,
                             mean, varianceSqrt );
    }
}

// Sets the value modus to the given index of valueCombo. See constants.h for the ValueModus type.
// Notifies all its tabs about the change.
void
TabWidget::setValueModus( int )
{
    if ( tabWidgetList.value( DEFAULT_TAB )->count() == 0 )
    {
        return;
    }

    this->valueModus = static_cast<ValueModus> ( valueCombo->itemData( valueCombo->currentIndex() ).toInt() );

    if ( valueModus == EXTERNAL_VALUES )
    {
        emit externalValueModusSelected( this ); // first check if external value modus is valid
    }
    else
    {
        setValueModus( valueModus );
    }
}

void
TabWidget::setValueModus( ValueModus modus )
{
    if ( tabWidgetList.value( DEFAULT_TAB )->count() == 0 )
    {
        return;
    }

    int idx = valueCombo->findData( modus );
    valueCombo->setCurrentIndex( idx == -1 ? 0 : idx );

    TabInterface* current = currentTabInterface();

    // always notify SystemTreeWidget, because following tabs may refer on its values
    if ( displayType == SYSTEM )
    {
        TreeView* systemTree = this->getActiveTreeView();
        if ( current != systemTree )
        {
            systemTree->valueModusChanged( valueModus );
        }
    }

    current->valueModusChanged( valueModus );
    valuesChanged();
}

bool
TabWidget::isOrder( DisplayType left, DisplayType right )
{
    return order.indexOf( right ) > order.indexOf( left );
}

void
TabWidget::updateValueCombo()
{
    valueCombo->disconnect();

    ValueModus selectedModus = static_cast<ValueModus> ( valueCombo->itemData( valueCombo->currentIndex() ).toInt() );
    valueCombo->clear();

    valueCombo->addItem( tr( ABSOLUTE_NAME ), ABSOLUTE_VALUES );

    if ( displayType == SYSTEM )
    {
        if ( isOrder( METRIC, SYSTEM ) )
        {
            valueCombo->addItem( tr( OWNROOT_NAME ), OWNROOT_VALUES );
            valueCombo->addItem( tr( METRICROOT_NAME ), METRICROOT_VALUES );
            valueCombo->addItem( tr( METRICSELECTED_NAME ), METRICSELECTED_VALUES );
            valueCombo->addItem( tr( PEER_NAME ), PEER_VALUES );
            valueCombo->addItem( tr( PEERDIST_NAME ), PEERDIST_VALUES );
        }
        if ( order.indexOf( METRIC ) == 0 )
        {
            if ( isOrder( CALL, SYSTEM ) )
            {
                valueCombo->addItem( tr( CALLROOT_NAME ), CALLROOT_VALUES );
                valueCombo->addItem( tr( CALLSELECTED_NAME ), CALLSELECTED_VALUES );
            }
        }
    }
    else if ( displayType == CALL )
    {
        if ( isOrder( METRIC, CALL ) )
        {
            valueCombo->addItem( tr( OWNROOT_NAME ), OWNROOT_VALUES );
            valueCombo->addItem( tr( METRICROOT_NAME ), METRICROOT_VALUES );
            valueCombo->addItem( tr( METRICSELECTED_NAME ), METRICSELECTED_VALUES );
        }
        if ( order.indexOf( METRIC ) == 0 )
        {
            if ( isOrder( SYSTEM, CALL ) )
            {
                valueCombo->addItem( tr( SYSTEMROOT_NAME ), SYSTEMROOT_VALUES );
                valueCombo->addItem( tr( SYSTEMSELECTED_NAME ), SYSTEMSELECTED_VALUES );
            }
        }
    }
    else // type == METRICTAB
    {
        valueCombo->addItem( tr( OWNROOT_NAME ), OWNROOT_VALUES );
    }

    if ( order.indexOf( METRIC ) == 0 )
    {
        valueCombo->addItem( tr( EXTERNAL_NAME ), EXTERNAL_VALUES );
    }

    // set selected item to previously selected if available
    int idx = valueCombo->findData( selectedModus );
    valueCombo->setCurrentIndex( idx == -1 ? 0 : idx );

    connect( valueCombo, SIGNAL( currentIndexChanged( int ) ),
             this, SLOT( setValueModus( int ) ) );
}

// update the view of the current tab element
//
/**
 * @brief TabWidget::valuesChanged
 * Notifies all active tabs, that the tree values have changed. If a tab
 * is inactive, changeInfo is set to true. The tab will be notified, if it becames active again.
 */
void
TabWidget::valuesChanged()
{
    TabInterface* current = currentTabInterface();
    if ( !current )
    {
        return;     // no tab is visible
    }

    // always notify SystemTree first, because following tabs may refer on its values
    if ( displayType == SYSTEM )
    {
        TreeView* systemTree = this->getActiveTreeView();
        if ( current != systemTree )
        {
            systemTree->valuesChanged();
        }
    }

    // save for all inactive tabs, that values have been changed -> onCurrentChanged
    foreach( TabInterface * ti, pluginTabHash.keys() )
    {
        changeInfo.insert( ti, ti == current ? false : true );

        if ( ti != current  && ti->widget()->isVisible() ) // notify all detached tabs
        {
            ti->valuesChanged();
        }
    }

    // notify active tab
    current->valuesChanged();

    updateValueWidget();
}

/** return the TabWidget that contains the widget of the given TabInterface */
DetachableTabWidget*
TabWidget::getParentTabWidget( TabInterface* tc )
{
    return tabWidgetList.value( pluginTabHash.value( tc ) );
}

/** signal currentChanged() is emitted when the visible tab element has changed; that signal gets connected to this slot;
 */
void
TabWidget::onCurrentChanged()
{
    if ( !Globals::getTabManager() || !Globals::getTabManager()->getTree( METRICTREE ) || !Globals::getTabManager()->getTree( METRICTREE )->getLastSelection() )
    {
        return; // initialisation not yet finished
    }
    valueWidget->clear();

    TabInterface* activeTab = currentTabInterface();

    // check all tabs if they have been activated or hidden
    foreach( DetachableTabWidget * tabWidget, tabWidgetList )
    {
        for ( int i = 0; i < tabWidget->count(); i++ )
        {
            TabInterface* tab    = tabWidget->getTabInterface( tabWidget->widget( i ) );
            bool          active = ( tab == activeTab );
            if ( active )
            {
                bool changedValues = changeInfo.value( tab );
                if ( changedValues ) // only called, if tree values have been changed while tab has been inactive
                {
                    tab->valuesChanged();
                    changeInfo.insert( tab, false );
                }
                updateValueWidget();
            }
            tab->setActive( active );
            updateToolbarStatus( tab );
        }
    }

    if ( getType() == CALL )
    {
        TreeView* view = dynamic_cast<TreeView*> ( activeTab );
        PluginManager::getInstance()->tabActivated( view->getTree()->getTreeType() ); // notify that tree has changed

        // Call of updateRowHeight is required if value view changes while call tab is inactive.
        // Invisible tree views don't react on sizeHintChanged signals -> send signal again if view becomes visible.
        view->updateRowHeight();
    }
}

/**
 * @brief TabWidget::manageToolBar
 * If a toolbar is added here, it will only be visible, if the corresponding tab is visible. If the tab is
 * detached, it will be added to to new window, otherwise it will be added to the main window.
 */
void
TabWidget::addToolBar( QToolBar* bar, TabInterface* tab )
{
    if ( !pluginTabHash.contains( tab ) )
    {
        qDebug() <<  "Warning: cannot add toolbar to non-existing tab ";
        Globals::debug( "Warning: cannot add toolbar to non-existing tab " );
        bar->setVisible( false );
        return;
    }
    DetachableTabWidget* tabWidget = getParentTabWidget( tab );
    bar->setVisible( false );
    toolbars.insert( tab, bar );
    tabWidget->setToolbar( tab->widget(), bar );
}
void
TabWidget::removeToolBar( QToolBar* bar, TabInterface* tab )
{
    DetachableTabWidget* tabWidget = getParentTabWidget( tab );
    bar->setVisible( false );
    toolbars.remove( tab );
    tabWidget->removeToolbar( tab->widget(), bar );
}

/** This slot is called, if the tab gets active because it has been moved to a new window. */
void
TabWidget::setActiveTab( TabInterface* tc )
{
    tc->valuesChanged();
    tc->setActive( true );
    updateToolbarStatus( tc );
}

/** Shows the corresponding toolbar, if a tab gets active. HIdes it, if it becomes invisible. */
void
TabWidget::updateToolbarStatus( TabInterface* tab )
{
    QToolBar* toolbar = toolbars.value( tab );
    if ( !toolbar || !tab->widget() )
    {
        return;
    }
    if ( tab->widget()->isVisible() )
    {
        // add toolbar to main window or to detached window
        QMainWindow* win = getParentTabWidget( tab )->getParentWindow( tab->widget() );
        if ( win )
        {
            win->addToolBar( toolbar );
        }
        toolbar->setVisible( true );
    }
    else
    {
        toolbar->setVisible( false );
    }
}


QSize
TabWidget::sizeHint() const
{
    // use sizehint of currenly visible tab, default implementation uses the maximum of all tabs
    QSize hint;
    if ( currentTabInterface() )
    {
        hint = currentTabInterface()->widget()->sizeHint();
    }
    else
    {
        hint = QSize();
    }
    hint.setWidth( hint.width() + 2 * LAYOUT_MARGIN + 2 * LAYOUT_SPACING );
    return hint;
}

/**
   enables/disables the given tab
 */
void
TabWidget::enableTab( TabInterface* tab, bool enabled )
{
    DetachableTabWidget* tabWidget = getParentTabWidget( tab );
    int                  index     = tabWidget->indexOf( tab->widget() );
    if ( index >= 0 )
    {
        tabWidget->setTabEnabled( index, enabled );
    }
}


/***************** settings ***********************/
/*
   //save tab settings
   //
   void
   TabWidget::saveSettings( QSettings& settings )
   {
    QString groupName = typeName();

    settings.beginGroup( groupName );

    // save settings for each tree
    foreach( TreeWidget * tree, treeHash.values() )
    {
        tree->saveSettings( settings );
    }

    //miscellaneous
    settings.setValue( "currentIndex", currentIndex() );
    settings.setValue( "selectionSyntax", selectionSyntax );
    settings.endGroup();
   }

   //load tab settings
   //
   bool
   TabWidget::loadSettings( QSettings& settings )
   {
    QString groupName = typeName();

    settings.beginGroup( groupName );

    // load settings for each tree
    foreach( TreeWidget * tree, treeHash.values() )
    {
        tree->loadSettings( settings );
    }

    //miscellaneous
    setCurrentIndex( settings.value( "currentIndex", 0 ).toInt() );
    selectionSyntax = ( SelectionSyntax )( settings.value( "selectionSyntax", 0 ).toInt() );
    settings.endGroup();

    valuesChanged();

    return true;
   }

 */

/************ miscellaneous **************/

DetachableTabWidget::DetachableTabWidget( QWidget* parent ) : QTabWidget( parent )
{
    tabBar()->setContextMenuPolicy( Qt::CustomContextMenu );
    connect( this->tabBar(), SIGNAL( customContextMenuRequested( const QPoint & ) ), SLOT( showContextMenu( const QPoint & ) ) );
    setMovable( true );
}

#include "PluginList.h"

void
DetachableTabWidget::showContextMenu( const QPoint& point )
{
    if ( point.isNull() )
    {
        return;
    }
    int      currentTabIndex = tabBar()->tabAt( point );
    QWidget* tabWidget       = this->widget( currentTabIndex );

    if ( !detachableTabs.contains( tabWidget ) )
    {
        return; // not detachable
    }

    CubePlugin* plugin = 0;
    if ( tabPluginHash.contains( tabWidget ) )
    {
        plugin = PluginList::getCubePlugin( tabPluginHash.value( tabWidget ) );
    }

    QMenu*   contextMenu = new QMenu();
    QAction* action      = new QAction( "Detach tab", this );
    action->setData( QVariant( currentTabIndex ) );
    connect( action, SIGNAL( triggered() ), this, SLOT( detachTabAction() ) );
    contextMenu->addAction( action );

    if ( plugin )
    {
        QString pluginName = plugin->name();
        pluginName.remove( "Plugin" );
        pluginName.remove( "plugin" );
        pluginName = pluginName.simplified();

        QAction* closeAction = new QAction( "Close " + pluginName + " Plugin", this );
        closeAction->setData( QVariant( currentTabIndex ) );
        connect( closeAction, SIGNAL( triggered() ), this, SLOT( closePlugin() ) );
        contextMenu->addAction( closeAction );
    }
    else
    {
        QAction* closeAction = new QAction( tr( "Close tab" ), this );
        closeAction->setData( QVariant( currentTabIndex ) );
        connect( closeAction, SIGNAL( triggered() ), this, SLOT( closeTab() ) );
        contextMenu->addAction( closeAction );
    }

    // show context menu
    contextMenu->exec( this->mapToGlobal( point ) );
    contextMenu->deleteLater();
}

/** closes non-plugin tab */
void
DetachableTabWidget::closeTab()
{
    QAction* action = qobject_cast<QAction*>( sender() );
    if ( action != 0 )
    {
        int      currentTabIndex = action->data().toInt();
        QWidget* tabWidget       = this->widget( currentTabIndex );
        removeTab( currentTabIndex );
        detachableTabs.removeAll( tabWidget );
    }
}

void
DetachableTabWidget::closePlugin()
{
    QAction* action = qobject_cast<QAction*>( sender() );
    if ( action != 0 )
    {
        int      currentTabIndex = action->data().toInt();
        QWidget* tabWidget       = widget( currentTabIndex );

        if ( tabPluginHash.contains( tabWidget ) )
        {
            PluginManager::getInstance()->closePlugin( tabPluginHash.value( tabWidget ) );
        }
    }
}

void
DetachableTabWidget::removeAllTabs()
{
    // remove detached tabs
    foreach( QWidget * widget, detachedTabs )
    {
        widget->setVisible( false );
        widget->deleteLater();
    }
    detachedTabs.clear();

    // remove tabs
    while ( count() > 0 )
    {
        removeTab( 0 );
    }
    tabHash.clear();
}

void
DetachableTabWidget::detachTab( int index )
{
    QWidget* tabWidget = widget( index );
    QSize    size      = tabWidget->size();
    QIcon    icon      = tabIcon( index );

    CloseableMainWindow* dialog = new CloseableMainWindow( this );

    // move toolbar from main window to detached window
    QToolBar* toolbar = toolbarHash.value( tabWidget );
    if ( toolbar )
    {
        dialog->addToolBar( toolbar );
    }

    dialog->setWindowTitle( tabText( index ) );
    dialog->setCentralWidget( tabWidget );
    tabWidget->setVisible( true );
    dialog->resize( size );
    dialog->setWindowIcon( icon );
    dialog->setVisible( true );
    dialog->setProperty( "tabWidget", qVariantFromValue( ( void* )tabWidget ) );
    dialog->setProperty( "tabIcon", icon );
    dialog->setProperty( "tabIndex", index );

    connect( dialog, SIGNAL( closed() ), this, SLOT( detachedTabClosed() ) );
    detachedTabs.append( dialog );

    // notify plugin
    TabInterface* ti = getTabInterface( tabWidget );
    ti->detachEvent( dialog, true );
}

QMainWindow*
DetachableTabWidget::getParentWindow( QWidget* tab )
{
    QMainWindow* parent = 0;
    while ( ( tab &&  !tab->isWindow() && tab->parentWidget() ) )
    {
        tab = tab->parentWidget();
    }
    parent = dynamic_cast<QMainWindow*> ( tab );
    return parent;
}


void
DetachableTabWidget::setToolbar( QWidget* widget, QToolBar* bar )
{
    toolbarHash.insert( widget, bar );

    QMainWindow* main = 0;
    if ( indexOf( widget ) >= 0 ) // visible tab
    {
        main = Globals::getMainWindow();
    }
    else  // detached tab
    {
        main = getParentWindow( widget );
    }
    if ( main )
    {
        main->addToolBar( bar );
    }
}

void
DetachableTabWidget::removeToolbar( QWidget* widget, QToolBar* bar )
{
    toolbarHash.remove( widget );

    QMainWindow* main = 0;
    if ( indexOf( widget ) >= 0 ) // visible tab
    {
        main = Globals::getMainWindow();
    }
    else   // detached tab
    {
        main = getParentWindow( widget );
    }
    if ( main )
    {
        main->removeToolBar( bar );
    }
}

TabInterface*
DetachableTabWidget::getTabInterface( QWidget* widget ) const
{
    return tabHash.value( widget );
}

void
DetachableTabWidget::addTabInterface( QWidget* widget, TabInterface* ti )
{
    tabHash.insert( widget, ti );
}

QList<TabInterface*> DetachableTabWidget::getTabInterfaces() const
{
    return tabHash.values();
}

/** detached tab closed -> move contents of the window back to the tab container */
void
DetachableTabWidget::detachedTabClosed()
{
    QMainWindow* dialog =  qobject_cast<QMainWindow*>( sender() );
    QWidget*     widget = ( QWidget* )dialog->property( "tabWidget" ).value<void*>();
    QIcon        icon   = dialog->property( "tabIcon" ).value<QIcon>();
    int          index  = dialog->property( "tabIndex" ).value<int>();

    // notify plugin
    TabInterface* ti = getTabInterface( widget );
    ti->detachEvent( dialog, false );

    dialog->layout()->removeWidget( widget );
    insertTab( index, widget, icon, dialog->windowTitle() );
    setCurrentIndex( index );
    detachedTabs.removeAll( dialog );

    // move toolbar from detached widget to main window
    QToolBar* toolbar = toolbarHash.value( widget );
    if ( toolbar )
    {
        toolbar->setVisible( false );
        dialog->removeToolBar( toolbar );
        Globals::getMainWindow()->addToolBar( toolbar );
    }
    dialog->deleteLater();
}

void
DetachableTabWidget::removeTabInterface( TabInterface* tc )
{
    tabHash.remove( tc->widget() );

    int index = indexOf( tc->widget() );
    if ( index >= 0 ) // visible tab
    {
        this->removeTab( index );
    }
    else // detached tab
    {
        QMainWindow* dialog = dynamic_cast<QMainWindow*> ( tc->widget()->parentWidget() );
        dialog->disconnect();
        detachedTabs.removeAll( dialog );
        detachableTabs.removeAll( dialog );
        dialog->deleteLater();
    }
}

void
DetachableTabWidget::detachTabAction()
{
    QAction* action = qobject_cast<QAction*>( sender() );
    if ( action != 0 )
    {
        int      currentTabIndex  = action->data().toInt();
        QWidget* tabWidget        = widget( currentTabIndex );
        bool     isAlreadyVisible = tabWidget->isVisible();

        detachTab( currentTabIndex );

        if ( !isAlreadyVisible )
        {
            TabInterface* tc = tabHash.value( tabWidget );
            emit( activated( tc ) );
        }
    }
}

void
DetachableTabWidget::setDetachable( QWidget* widget, const QString& pluginName )
{
    detachableTabs.append( widget );
    if ( !pluginName.isEmpty() )
    {
        tabPluginHash.insert( widget, pluginName );
    }
}
