/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/





#ifndef _TABWIDGET2
#define _TABWIDGET2

#include <QSettings>
#include <QTabWidget>
#include <QComboBox>
#include <QHash>
#include <QMainWindow>

#include "Constants.h"
#include "InfoWidget.h"
#include "PluginServiceExports.h"

namespace cube
{
class Cube;
}

namespace cubepluginapi
{
class CubePlugin;
}

namespace cubegui
{
class TabInterface;
class ValueWidget;
class TreeView;
class Tree;
class DetachableTabWidget;

/**
   A TabWidget consists of three graphical elements which are vertically aligned:
   - a combo box to choose the value mode
   - a tabbar with a group of tabs, e.g. TreeViews or other classes that derive from TabInterface
   - a value widget

   Cube creates three instances of TabWidget with different types (TabWidgetType):
   - the metric tab contains only the metric tree
   - the call tab contains the call tree and a flat profile
   - the system tab contains the system tree and may contain tabs from plugins
 */
class TabWidget : public QWidget
{
    Q_OBJECT

signals:
    void
    externalValueModusSelected( TabWidget* );

public:

    TabWidget( DisplayType displayType );

    // initialize the tab widget
    void
    initialize( const QList<DisplayType>& order );

    void
    setOrder( const QList<DisplayType>& order );

    int
    createSystemTabWidget( const QString& label,
                           TabType        tabType = DEFAULT_TAB );

    void
    addPluginTab( TabInterface*,
                  const QString& pluginName,
                  int            tabWidgetID = DEFAULT_TAB );

    void
    removePluginTab( TabInterface* );

    int
    addTab( TabInterface* tc,
            bool          detachable = false,
            int           tabWidgetID = DEFAULT_TAB );

    int
    addTreeTab( TreeView* );

    TreeView*
    getActiveTreeView();

    /************ get methods **********/

    // return the current value modus
    ValueModus
    getValueModus();

    // return the precision widget
    ValueWidget*
    getValueWidget();

    /*********** initialization / clean up **************/

    // called when files are closed;
    // clear the tab, no data is shown
    void
    cubeClosed();

    /************* settings **********/

    // save tab settings
    // void saveSettings( QSettings& settings );

    // load tab settings
    // bool loadSettings( QSettings& settings );

    /************** miscellaneous ****************/

    // disable/enable the given tab, e.g. required if system widget is 1st
    void
    enableTab( TabInterface* tab,
               bool          enabled );

    // return the minimal width necessary to display all information
    virtual
    QSize
    sizeHint() const;

    DisplayType
    getType() const;

    void
    updateValueWidget();

    void
    setValueModus( ValueModus modus );

    /** detaches the given tab interface */
    void
    detachTab( TabInterface* ti );

    /** sets the given TabInterface as active tab */
    void
    toFront( TabInterface* tc );

    /** sets the given TabInterface as active tab */
    void
    toFront( const QString& label );

    void
    addToolBar( QToolBar*,
                TabInterface* );
    void
    removeToolBar( QToolBar*,
                   TabInterface* );

    void
    valuesChanged();

private slots:

    // signal currentChanged() is emitted when the visible tab element has changed;
    // that signal gets connected to this slot
    void
    onCurrentChanged();

    void
    setValueModus( int index );

    void
    setActiveTab( TabInterface* tc );

    void
    systemTabChanged( int nr );

private:
    /*********************/
    // the 3 components of this widget
    QTabWidget*  mainTabWidget;   // system tab consists of nested tab bars
    ValueWidget* valueWidget;
    QComboBox*   valueCombo;

    DisplayType displayType;                       // type: metric, call or system tab, see constants.h for TabWidgetType
    cube::Cube* cube;                              // the cube database
    ValueModus  valueModus;                        // value modus, see constants.h

    QHash<QWidget*, TreeView*>      treeHash;      // contains only TreeWidgets
    QHash<TabInterface*, QToolBar*> toolbars;      // contains tabs which own a toolbar
    QList<QWidget*>                 pluginWidgets; // contains all registered plugins with tab component
    QList<DisplayType>              order;
    QHash<TabInterface*, bool>      changeInfo;    // true, if tree values have been changed since tab has been inactive
    QList<DetachableTabWidget*>     tabWidgetList; // index = tab widget id , value = tab widget

    // only for system tabs
    QHash<QWidget*, DetachableTabWidget*> systemTabs;    // child of mainTabWidget, which may share a value combo and value view
    QHash<TabInterface*, int>             pluginTabHash; // plugin tab -> parent tab widget id

    /*********************/
    void
    updateValueCombo();

    bool
    isOrder( DisplayType left,
             DisplayType right );

    TabInterface*
    currentTabInterface() const;

    void
    updateToolbarStatus( TabInterface* tab );

    DetachableTabWidget*
    getParentTabWidget( TabInterface* tc );
};

/** TabWidget whose tabs can be detached to a separate Window */
class DetachableTabWidget : public QTabWidget
{
    Q_OBJECT
public:
    DetachableTabWidget( QWidget* parent = NULL );
    void
    setDetachable( QWidget*       widget,
                   const QString& pluginName = QString() );
    void
    removeAllTabs();
    void
    removeTabInterface( TabInterface* );

    void
    setToolbar( QWidget*  widget,
                QToolBar* bar );
    void
    removeToolbar( QWidget*  widget,
                   QToolBar* bar );

    TabInterface*
    getTabInterface( QWidget* ) const;
    void
    addTabInterface( QWidget*,
                     TabInterface* );

    QList<TabInterface*>
    getTabInterfaces() const;

    void
    detachTab( int );

    QMainWindow*
    getParentWindow( QWidget* tab );

signals:
    /** this signal is emitted, if a tab get detached which wasn't visible before */
    void
    activated( TabInterface* tc );

private slots:
    void
    showContextMenu( const QPoint& point );
    void
    detachTabAction();
    void
    detachedTabClosed();
    void
    closePlugin();
    void
    closeTab();

private:
    QHash<QWidget*, QString>   tabPluginHash;
    QHash<QWidget*, QToolBar*> toolbarHash;        // tab widget -> toolbar

    QList<QWidget* >               detachableTabs; // tab which can be detached
    QList<QWidget*>                detachedTabs;   // detached tabs, which should be deleted if cube is closed
    QHash<QWidget*, TabInterface*> tabHash;        // contains all tab widgets
};

class CloseableMainWindow : public QMainWindow
{
    Q_OBJECT
public:
    CloseableMainWindow( QWidget* parent ) : QMainWindow( parent )
    {
    }
signals:
    void
    closed();

    // QWidget interface
protected:
    void
    closeEvent( QCloseEvent* )
    {
        emit closed();
    }
};
}
#endif
