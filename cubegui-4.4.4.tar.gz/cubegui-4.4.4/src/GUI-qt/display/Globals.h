/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#ifndef GLOBALS_H
#define GLOBALS_H

#include <QColor>
#include <QMainWindow>
#include <QTextStream>
#include <QHash>
#include <QVariant>
#include "Constants.h"
#include "Cube.h"

#define PROGRESS_STEPS 10

namespace cubepluginapi
{
class ValueView;
}

namespace cubegui
{
enum MessageType { Verbose, Information, Warning, Error, Critical };

class ColorMap;
class PrecisionWidget;
class MainWidget;
class TabManager;
class SettingsHandler;
class InternalSettingsHandler;
class ValueViewConfig;
class TreeItem;

struct CallDisplayConfig
{
public:
    CallDisplayConfig();
    bool hideArguments;
    bool hideReturnValue;
    bool hideModules;
    int  hideClassHierarchy;
    bool demangleFunctions;
};


class Globals
{
    friend class MainWidget;
    friend class PluginManager;
    friend class ValueViewConfig;
public:
    /** returns the corresponding color of the currently selected colormap */
    static QColor
    getColor( double value,
              double minValue,
              double maxValue,
              bool   whiteForZero = true );

    /** prints the given text into the status line below the main widget */
    static void
    setStatusMessage( const QString& msg,
                      MessageType    type = Information,
                      bool           isLogged = true );

    static QPair<QString, QString>
    formatNumberAndUnit( double                   value,
                         const QString&           unit,
                         bool                     integerType = false,
                         PrecisionFormat          format = FORMAT_TREES,
                         const cubegui::TreeItem* item = 0 );

    static QString
    formatNumber( double                   value,
                  bool                     integerType = false,
                  PrecisionFormat          format = FORMAT_TREES,
                  const cubegui::TreeItem* item = 0 );

    static QString
    formatNumber( double          value,
                  double          referenceValue,
                  bool            scientificSmall = false,
                  bool            integerType = false,
                  PrecisionFormat format = FORMAT_TREES );

    static double
    getRoundNumber( PrecisionFormat format );

    static double
    getRoundThreshold( PrecisionFormat format );

    static QMainWindow*
    getMainWindow();

    static TabManager*
    getTabManager();

    static void
    setVerbose( bool value );

    static QTextStream&
    debug( const QString& sender );

    static bool
    isExperimental();

    static void
    setExperimental( bool value );

    static CallDisplayConfig
    getCallDisplayConfig();
    static void
    setCallDisplayConfig( const CallDisplayConfig& value );

    static void
    clearSettingsHandler()
    {
        settingsHandlerList.clear();
    }
    static void
    addSettingsHandler( SettingsHandler* s )
    {
        settingsHandlerList.append( s );
    }
    static const QList<SettingsHandler*>&
    getSettingsHandler()
    {
        return settingsHandlerList;
    }
    static void
    sendSynchronizationData();

    static cubepluginapi::ValueView*
    getValueView( cube::DataType type );

    static void
    setValueViewIconHeight( int height );

    static int
    getValueViewIconHeight();

    static void
    setCurrentMetric( cube::Metric* metric );
    static QString
    getMetricUnit();

    /** alternative method to the implementation of an InternalSettingsHandler for single values;
        sets a setting with the given name and value as startup setting, which is read at program start */
    static void
    setGlobalSetting( QString name, QVariant value )
    {
        globalSettingValues.insert( name, value );
    }
    static QVariant
    getGlobalSetting( QString name )
    {
        return globalSettingValues.value( name );
    }
    static QHash<QString, QVariant>&
    getGlobalSettingValueHash()
    {
        return globalSettingValues;
    }
private:
    static PrecisionWidget*  precisionWidget;
    static ColorMap*         defaultColorMap;
    static ColorMap*         colorMap;
    static MainWidget*       mainWidget;
    static TabManager*       tabManager;
    static bool              verbose;
    static bool              experimental;
    static QTextStream*      outStream;
    static CallDisplayConfig callDisplayConfig;
    static int               valueViewIconHeight;
    static cube::Metric*     metric;
    static QString           metricUnit;

    static QList<SettingsHandler*>                          settingsHandlerList;
    static cubepluginapi::ValueView*                        defaultValueView;
    static QHash<cube::DataType, cubepluginapi::ValueView*> valueViews;
    static QHash<QString, QVariant>                         globalSettingValues;
    static InternalSettingsHandler*                         simpleSettingsHandler;

    static void
    initialize( MainWidget* m,
                TabManager* t );
    static PrecisionWidget*
    getPrecisionWidget();
    static void
    setColorMap( ColorMap* map = 0 );
    static ColorMap*
    getColorMap();
    static void
    setValueView( cube::DataType            type,
                  cubepluginapi::ValueView* view = 0 );
    static void
    removeValueView( cubepluginapi::ValueView* view );
};
}
#endif // GLOBALS_H
