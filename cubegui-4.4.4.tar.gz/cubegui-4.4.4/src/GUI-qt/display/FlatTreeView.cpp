/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/



#include "config.h"


#include "CubeRegion.h"


#include "FlatTreeView.h"
#include "FlatTree.h"
#include "Globals.h"
#include "TabManager.h"

using namespace cubegui;
using namespace std;

FlatTreeView::FlatTreeView( TreeModelInterface* modelInterface,
                            const QString&      tabLabel ) : TreeView( modelInterface, tabLabel )
{
    isActive = false;
}

void
FlatTreeView::setActive( bool active )
{
    isActive = active;
    /* select all entries in the flat tree, that have the same label as the selected entries
       in the call tree
     */
    if ( active )
    {
        Tree* callTree = Globals::getTabManager()->getTree( CALLTREE );

        QStringList selectedItems;
        foreach( TreeItem * item, callTree->getSelectionList() )
        {
            if ( !selectedItems.contains( item->getName() ) )
            {
                selectedItems.append( item->getName() );
            }
        }
        QModelIndexList found = searchItems( selectedItems );
        selectItems( found ); // can be optimized; only required if selection has changed
    }
}

void
FlatTreeView::valuesChanged()
{
    if ( !isActive ) // view has been inactive and is going to be active
    {
        // recalculate values of this tree, if values of left tree have been changed while beeing inactive;
        // disable notification to prevent recursion
        emit recalculateRequest( getTree(), false );
    }
}

/**
 * creates context menu items for call trees
 */
void
FlatTreeView::fillContextMenu()
{
    contextMenu->addAction( contextMenuHash.value( TreeItemInfo ) );
    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( ExpandMenu ) );
    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( ExpandMenu ) );

    QMenu* hidingMenu = contextMenu->addMenu( tr( "Hiding" ) );
    hidingMenu->setWhatsThis( "Hide subtrees." );
    hidingMenu->addAction( contextMenuHash.value( HidingThreshold ) );
    hidingMenu->addSeparator();
    hidingMenu->addAction( contextMenuHash.value( DynamicHiding ) );
    hidingMenu->addAction( contextMenuHash.value( StaticHiding ) );
    hidingMenu->addAction( contextMenuHash.value( HideItem ) );
    hidingMenu->addAction( contextMenuHash.value( UnhideItem ) );
    hidingMenu->addAction( contextMenuHash.value( NoHiding ) );

    contextMenu->addAction( contextMenuHash.value( FindItems ) );
    contextMenu->addAction( contextMenuHash.value( ClearFound ) );
    contextMenu->addAction( contextMenuHash.value( SortingMenu ) );
    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( UserDefinedMinMax ) );
    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( CopyClipboard ) );
    contextMenu->addSeparator();

    // HidingThreshold can only be set if hiding is enabled
    contextMenuHash.value( HidingThreshold )->setEnabled( !contextMenuHash.value( NoHiding )->isChecked() );
    if ( contextMenuItem && contextMenuItem->isTopLevelItem() )
    {
        contextMenuHash.value( HideItem )->setEnabled( false ); // disabled for root item
    }
}

QString
FlatTreeView::getContextDescription( TreeItem* item )
{
    if ( item->getCubeObject() && item->getType() == REGIONITEM )
    {
        cube::Region* region = static_cast<cube::Region* >( item->getCubeObject() );
        std::string   descr  = "Region name:    " + region->get_name() + "\n";
        descr = descr + "Region description:    " + region->get_descr() + "\n";

        TreeView*       callTreeView = Globals::getTabManager()->getView( CALLTREE );
        QModelIndexList found        = callTreeView->searchItems( QStringList() << item->getName() );
        descr = descr + "References in call tree: " + QString::number( found.size() ).toStdString() + "\n";

        stringstream sstr1;
        string       _str_beg_ln;
        if ( region->get_begn_ln() != -1 )
        {
            sstr1 << region->get_begn_ln();
            sstr1 >> _str_beg_ln;
        }
        else
        {
            _str_beg_ln = "undefined";
        }

        stringstream sstr2;
        string       _str_end_ln;
        if ( region->get_end_ln() != -1 )
        {
            sstr2 << region->get_end_ln();
            sstr2 >> _str_end_ln;
        }
        else
        {
            _str_end_ln = "undefined";
        }
        descr = descr + "Beginning line:   " + _str_beg_ln + "\n";
        descr = descr + "Ending line:   " + _str_end_ln + "\n";
        descr = descr + "Paradigm:   " + region->get_paradigm() + "\n";
        descr = descr + "Role:   " + region->get_role() + "\n";
        descr = descr + "Source file:   " + region->get_mod() + "\n";
        descr = descr + "Url:   " + region->get_url() + "\n";


        const std::map<std::string, std::string>& attrs = region->get_attrs();
        descr = descr + "\n" +  "Attributes :";
        for ( std::map<std::string, std::string>::const_iterator iter = attrs.begin(); iter != attrs.end(); ++iter )
        {
            descr = descr + "\n" +  iter->first + " : " + iter->second;
        }



        return QString( descr.c_str() );
    }
    return "";
}
