/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"

#include "MetricTreeView.h"
#include "CallTree.h"
#include "Globals.h"
#include "TabManager.h"
using namespace cubegui;

MetricTreeView::MetricTreeView( TreeModelInterface* model,
                                const QString&      tabLabel ) : TreeView( model, tabLabel )
{
    this->setUniformRowHeights( false ); // items of metric tree may have different size, if special value view is used
}

/**
 * @brief MetricTreeView::selectionIsValid checks if newItem can be added to the current selection
 * @param oldItems previously selected tree items
 * @param newItem item that should become selected
 * @return true, if the item can be added to the current selection
 */
bool
MetricTreeView::selectionIsValid( QList<TreeItem*>& oldItems, TreeItem* newItem )
{
    if ( oldItems.size() > 0 )
    {
        if ( newItem->isDerivedMetric() || oldItems.at( 0 )->isDerivedMetric() )
        {
            QString message( "Multiple selection of derived metrics is not possible." );
            Globals::setStatusMessage( message, Error );
            return false;
        }
    }

    bool    sameUnit = true;
    QString first_uom, second_uom;
    for ( int i = 0; i < oldItems.size() && sameUnit; i++ )
    {
        const TreeItem* oldItem = oldItems.at( i )->getTopLevelItem();
        first_uom  = QString::fromStdString( ( ( cube::Metric* )( oldItem->getCubeObject() ) )->get_uom() );
        second_uom = QString::fromStdString( ( ( cube::Metric* )( newItem->getCubeObject() ) )->get_uom() );
        if ( first_uom != second_uom )
        {
            sameUnit = false;
            break;
        }
    }
    if ( !sameUnit )
    {
        QString message( "Multiple metric selection is possible only if the unit of measurement is compatible. \nIn this case \"" );
        message += first_uom;
        message += "\" is incompatible with \"";
        message += second_uom;
        message += "\"";
        Globals::setStatusMessage( message, Error );
        return false;
    }

    bool sameRoot = true;
    for ( int i = 0; i < oldItems.size() && sameRoot; i++ )
    {
        const TreeItem* first  = oldItems.at( i )->getTopLevelItem();
        const TreeItem* second = newItem->getTopLevelItem();
        if ( first != second )
        {
            sameRoot = false;
            break;
        }
    }

    if ( !sameRoot )
    {
        Globals::setStatusMessage( "Be careful. Metrics with different roots might be incompatible for operation \"+\".", Warning );
    }

    return true;
}

void
MetricTreeView::selectionChanged( const QItemSelection& selected,
                                  const QItemSelection& deselected )
{
    Globals::getTabManager()->updateValueViews(); // selection of new metric may change the icon size of the tree items in all trees
    TreeView::selectionChanged( selected, deselected );
}

/**
 * creates context menu items for call trees
 */
void
MetricTreeView::fillContextMenu()
{
    foreach( QAction * action, metricContextMenuHash.values() )     // enable all metric context menu actions
    {
        action->setEnabled( true );
    }

    contextMenu->addAction( contextMenuHash.value( TreeItemInfo ) );
    contextMenu->addAction( contextMenuHash.value( Documentation ) );

    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( ExpandMenu ) );

    contextMenu->addAction( contextMenuHash.value( FindItems ) );
    contextMenu->addAction( contextMenuHash.value( ClearFound ) );
    contextMenu->addAction( contextMenuHash.value( SortingMenu ) );
    contextMenu->addSeparator();
    contextMenu->addAction( contextMenuHash.value( CopyClipboard ) );
    contextMenu->addSeparator();
}

QString
MetricTreeView::getContextDescription( TreeItem* item )
{
    cube::Metric* _met    = static_cast<cube::Metric* >( item->getCubeObject() );
    std::string   content = "Metric :  " + _met->get_descr() + "\n";

    // store the description text in the string "descr";
    // we get the description from the cube object "cubeObject" of the clicked item,
    // where we have to distinguish on its type
    std::string title;

    std::string uniq_name;
    std::string disp_name;
    std::string dtype;
    std::string uom;
    std::string val;
    std::string url;
    std::string kind;
    std::string descr;
    std::string cubepl_expression;
    std::string cubepl_init_expression;
    std::string cubepl_plus_expression;
    std::string cubepl_minus_expression;
    std::string cubepl_aggr_expression;
    title = "No information";

    uniq_name               = _met->get_uniq_name();
    disp_name               = _met->get_disp_name();
    dtype                   = _met->get_dtype();
    uom                     = _met->get_uom();
    val                     = _met->get_val();
    url                     = _met->get_url();
    descr                   = _met->get_descr();
    kind                    = _met->get_metric_kind();
    cubepl_expression       = _met->get_expression();
    cubepl_init_expression  = _met->get_init_expression();
    cubepl_plus_expression  = _met->get_aggr_plus_expression();
    cubepl_minus_expression = _met->get_aggr_minus_expression();
    cubepl_aggr_expression  = _met->get_aggr_aggr_expression();


    content = content +
              "Display name :  " + disp_name + "\n" +
              "Unique name :  " + uniq_name + "\n" +
              "Data type :  " + dtype + "\n" +
              "Unit of measurement :  " + uom + "\n" +
              "Value :  " + val + "\n" +
              "URL :  " + url + "\n" +
              "Kind of values :  " + kind;

    if ( !( cubepl_expression.compare( "" ) == 0 ) )
    {
        content = content + "\n" +  "CubePL expression :  " +  cubepl_expression;
    }
    if ( !( cubepl_init_expression.compare( "" ) == 0 ) )
    {
        content = content + "\n" +  "CubePL Init expression :  " +  cubepl_init_expression;
    }
    if ( !( cubepl_plus_expression.compare( "" ) == 0 ) )
    {
        content = content + "\n" +  "CubePL Plus expression :  " +  cubepl_plus_expression;
    }
    if ( !( cubepl_minus_expression.compare( "" ) == 0 ) )
    {
        content = content + "\n" +  "CubePL Minus expression :  " +  cubepl_minus_expression;
    }
    if ( !( cubepl_aggr_expression.compare( "" ) == 0 ) )
    {
        content = content + "\n" +  "CubePL Aggr expression :  " +  cubepl_aggr_expression;
    }

    content = content + "\n\n" + ( ( _met->isConvertible() ) ? "Convertible to data" : "Non convertible to data" );
    content = content + "\n" + ( ( _met->isCacheable() ) ? "Cacheable" : "Non cacheable" );
    content = content + "\n" + ( ( _met->isGhost() ) ? "Ghost metric" : "Normal metric" );

    const std::map<std::string, std::string>& attrs = _met->get_attrs();
    content = content + "\n" +  "Attributes :";
    for ( std::map<std::string, std::string>::const_iterator iter = attrs.begin(); iter != attrs.end(); ++iter )
    {
        content = content + "\n" +  iter->first + " : " + iter->second;
    }


    return QString( content.c_str() );
}
