/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2018                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include <QTextBrowser>
#include <QBuffer>
#include "HtmlWidget.h"

namespace cubegui
{
/*-------------------------------------------------------------------------*/
/**
 * @class HtmlWidget
 * @brief Provides a simple HTML-browser widget
 *
 * This class provides a simple HTML-browser widget based on Qt's
 * QTextBrowser class. Its main extension over QTextBrowser is the
 * ability to load HTML pages as well as referenced resources (i.e.,
 * images in particular) directly from a web server or a file,
 * respectively.
 *
 * This widget is not intended to be used as a full-featured web
 * browser, but more as an easy way to display online help messages
 * in HTML format. When writing the documents to be displayed, keep
 * in mind that this widget only supports a limited subset of HTML
 * (see Qt's reference documentation for details).
 */
/*-------------------------------------------------------------------------*/
class HtmlTextBrowser;
class HtmlWidgetTextView : public HtmlWidget
{
    Q_OBJECT

public:
    HtmlWidgetTextView( QWidget* parent = 0 );

    void
    showUrl( const QUrl& url );
    void
    showHtml( const QString& html );

public slots:
    void
    back();
    void
    forward();

private slots:
    void
    onUrlLoaded( const QUrl&       url,
                 const QByteArray& buffer );

    void
    onLoadingFinished( const QUrl& url,
                       bool        ok );

    void
    onLinkClicked( QUrl url );

    void
    scroll();

private:
    HtmlTextBrowser* view;
    QUrl             lastUrl;
    QString          anchor;
    bool             first; // workaround for bug #855
    QList<QUrl>      history;
    int              position;
    bool             changeHistory;
    void
    addToHistory( QUrl url );
};

class HtmlTextBrowser : public QTextBrowser
{
public:
    /**
        for internal use: loads all referenced resources
     */
    virtual QVariant
    loadResource( int         type,
                  const QUrl& name );
    void
    setUrl( const QString& url );

private:
    QUrl baseUrl;
    QByteArray
    loadUrlResource( const QUrl& url );
};
}
