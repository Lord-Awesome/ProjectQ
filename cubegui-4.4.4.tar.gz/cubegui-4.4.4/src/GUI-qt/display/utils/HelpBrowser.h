/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/



#ifndef _HELPBROWSER_H
#define _HELPBROWSER_H

#include "config-frontend.h"  // defines QT_WEBENGINE_LIB

#include <QTextBrowser>
#include <QDialog>
#include <QUrl>
#include <QBuffer>
#ifdef QT_WEBENGINE_LIB
#include <QWebEngineView>
#endif
#include "HtmlWidget.h"

/*-------------------------------------------------------------------------*/
/**
 * @class HelpBrowser
 * @brief Provides a window which displays HTML help text. Use getInstance()
 * to reuse the current instance, if available.
 */
/*-------------------------------------------------------------------------*/

namespace cubegui
{
class HtmlWidget;

class HelpBrowser : public QWidget
{
    Q_OBJECT

public:
    static HelpBrowser*
    getInstance( const QString title = "Cube Help Browser" );

public slots:
    /** displays the contents of the given url in a browser widget */
    void
    showUrl( const QString& url,
             QString        errorMessage = "" );

    /** displays the contents of the given url in a browser widget */
    void
    showUrl( const QUrl& url,
             QString     errorMessage = "" );

    /** displays the raw html data in in a browser widget */
    void
    showHtml( QString& html );

private slots:
    void
    loadFinished( QUrl url );

    void
    loadFailed( QUrl url );

private:
    HelpBrowser( const QString& title );

    /// Browser widget used to display the help text
    QBuffer     buffer;           // buffer for contents of URL
    QString     errorMessage;     // message to show, if URL could not be loaded
    HtmlWidget* html;

    static HelpBrowser* single;
};
}
#endif
