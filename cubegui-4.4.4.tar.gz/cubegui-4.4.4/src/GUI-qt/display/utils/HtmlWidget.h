/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2018                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#ifndef _HTMLWIDGET_H
#define _HTMLWIDGET_H
#include <QWidget>
#include <QList>
#include <QUrl>

namespace cubegui
{
/*-------------------------------------------------------------------------*/
/**
 * @class HtmlWidget
 * @brief Provides an interface for a HTML-browser widget
 */
/*-------------------------------------------------------------------------*/

class HtmlWidget : public QWidget
{
    Q_OBJECT
public:
    HtmlWidget();

    static HtmlWidget*
    createHtmlWidget();

    void
    showUrl( const QString& mirror );

    virtual void
    showHtml( const QString& html ) = 0;

    virtual void
    showUrl( const QUrl& url ) = 0;

    /** load previous document */
    virtual void
    back()
    {
    }
    /** load next document */
    virtual void
    forward()
    {
    }

    static QList<QUrl>
    getMirrorList( const QString& url );

protected:
    /** used by derived classes to emit the signals below */
    void
    loaded( const QUrl& url,
            bool        ok );

signals:
    /** emitted, if URL has been sucessfully loaded */
    void
    urlLoaded( QUrl url );

    /** emitted, if loading of the given URL has failed */
    void
    loadingFailed( QUrl url );

private:
    QList<QUrl>    urlList;
    QList<QString> mirrorList;
    QString        lastMirror;
    QString        lastUrl;
};
}
#endif   /* !_HTMLWIDGET_H */
