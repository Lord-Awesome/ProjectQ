/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2019                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"
#include "HtmlWidget.h"
#include "Environment.h"
#include "PluginManager.h"

#ifdef QT_WEBENGINE_LIB
#include "HtmlWidgetWebEngine.h"
#else
#include "HtmlWidgetTextView.h"
#endif

using namespace std;
using namespace cubegui;

HtmlWidget::HtmlWidget()
{
    lastUrl    = "";
    lastMirror = "";
}


HtmlWidget*
HtmlWidget::createHtmlWidget()
{
#ifdef QT_WEBENGINE_LIB
    return new HtmlWidgetWebEngine;
#else
    return new HtmlWidgetTextView;
#endif
}

void
HtmlWidget::loaded( const QUrl& url, bool ok )
{
    //qDebug() << "HtmlWidget: Tried out mirror" << url << ok;
    if ( ok )
    {
        if ( !mirrorList.isEmpty() )
        {
            lastMirror = mirrorList.first();
        }
        emit urlLoaded( url );
        urlList.clear();
    }
    else
    {
        if ( !urlList.isEmpty() )
        {
            mirrorList.takeFirst();
            showUrl( urlList.takeFirst() );
        }
        else
        {
            showHtml( "" );
            Globals::setStatusMessage( "Failed to load Url " + url.toString(), Information );
            emit loadingFailed( url );
            urlList.clear();
        }
    }
}

/** Loads the given url. If the string contains the tag "@mirror@", the tag is replaced with each defined mirror until
 * a vaild URL is found
 */
void
HtmlWidget::showUrl( const QString& url )
{
    if ( lastUrl == url )
    {
        emit urlLoaded( url );
        return;
    }
    lastUrl = url;

    if ( url.contains( "@mirror" ) )
    {
        // Check whether HTTP access to online documentation should be disabled
        bool no_http = env_str2bool( getenv( "CUBE_DISABLE_HTTP_DOCS" ) );
        bool success = false;

        cube::Cube*                         cube    = PluginManager::getInstance()->getCube();
        const std::vector<std::string>&     mirrors = cube->get_mirrors();
        vector<std::string>::const_iterator it      = mirrors.begin();

        while ( !success && it != mirrors.end() )
        {
            QString tmpUrl = url;
            tmpUrl.replace( QString( "@mirror@" ), QString::fromStdString( *it ) );
            if ( no_http && ( tmpUrl.startsWith( "http://" ) || tmpUrl.startsWith( "https://" ) ) )
            {
                ++it;

                continue;
            }
            if ( tmpUrl.trimmed().length() > 0 )
            {
                urlList.append( QUrl( tmpUrl ) );
                mirrorList.append( QString::fromStdString( *it ) );
            }
            ++it;
        }
        if ( !lastMirror.isEmpty() ) // prepend last successfully used mirror
        {
            QString tmpUrl = url;
            tmpUrl.replace( QString( "@mirror@" ), lastMirror );
            urlList.prepend( QUrl( tmpUrl ) );
            mirrorList.prepend( lastMirror );
        }
    }
    else
    {
        urlList.append( url );
    }
    if ( urlList.size() > 0 )
    {
        showUrl( urlList.takeFirst() );
    }
    else
    {
        Globals::setStatusMessage( "No mirrors found in the profile", Information );
    }
}
