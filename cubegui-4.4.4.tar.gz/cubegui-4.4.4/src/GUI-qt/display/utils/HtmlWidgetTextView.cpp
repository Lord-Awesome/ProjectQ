/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2018                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"


#include <iostream>
#include <QBuffer>
#include <QDebug>
#include <QEventLoop>
#include <QVBoxLayout>
#include <QTimer>

#include "HtmlWidgetTextView.h"
#include "DownloadThread.h"

using namespace std;
using namespace cubegui;

/*--- Constructors & destructor -------------------------------------------*/

/**
 * @brief Constructs an empty instance
 *
 * Constructs a new, empty TextViewHtmlWidget instance width the given @p parent.
 *
 * @param  parent  Parent widget
 */
HtmlWidgetTextView::HtmlWidgetTextView( QWidget* )
{
    first         = true;
    position      = -1;
    changeHistory = true;
    view          = new HtmlTextBrowser();
    setLayout( new QVBoxLayout );
    layout()->setContentsMargins( 0, 0, 0, 0 );
    layout()->addWidget( view );

    view->setOpenExternalLinks( true );
    connect( view, SIGNAL( sourceChanged( QUrl ) ), this, SLOT( onLinkClicked( QUrl ) ) );
}

void
HtmlWidgetTextView::showHtml( const QString& html )
{
    view->setHtml( html );
}

void
HtmlWidgetTextView::onLoadingFinished( const QUrl& url, bool ok )
{
    this->loaded( url, ok );
    if ( ok )                // update Url history
    {
        if ( changeHistory ) // don't change history list, if back/forward have been chosen
        {
            addToHistory( url );
        }
    }
    changeHistory = true;
}

/*--- browser history -------------------------------------------------*/

/** called if user has clicked on a link */
void
HtmlWidgetTextView::onLinkClicked( QUrl url )
{
    QUrl absoluteUrl;
    if ( url.isRelative() )
    {
        absoluteUrl = lastUrl.resolved( url );
    }
    else
    {
        absoluteUrl = url;
    }
    addToHistory( absoluteUrl );
}

void
HtmlWidgetTextView::addToHistory( QUrl url )
{
    lastUrl = url;
    int count = history.size() - 1 - position;
    for ( int i = 0; i < count; i++ )
    {
        history.removeLast();
    }
    history.append( url );
    position = history.size() - 1;
}

void
HtmlWidgetTextView::back()
{
    changeHistory = false;
    if ( position > 0 ) // not first element
    {
        showUrl( QUrl( history.at( --position ) ) );
    }
}

void
HtmlWidgetTextView::forward()
{
    changeHistory = false;
    if ( position < history.size() - 1 ) // not last element
    {
        showUrl( history.at( ++position ) );
    }
}

/*--- Loading of contents -------------------------------------------------*/

void
HtmlWidgetTextView::showUrl( const QUrl& url )
{
    QList<QUrl> mirrorList;
    mirrorList.append( url );

    // check if current URL base is already loaded
    bool    alreadyLoaded = false;
    QString lastBase      = lastUrl.toString( QUrl::RemoveFragment );
    if ( !lastBase.isEmpty() )
    {
        foreach( QUrl url, mirrorList )
        {
            QString base = url.toString( QUrl::RemoveFragment );
            if ( base == lastBase )
            {
                alreadyLoaded = true;
                break;
            }
        }
    }
    if ( !alreadyLoaded )     // new URL requested
    {
        view->clear();        // Clear the document
        DownloadThread* download = new DownloadThread( mirrorList );
        connect( download, SIGNAL( downloadFinished( QUrl, const QByteArray & ) ), this, SLOT( onUrlLoaded( QUrl, const QByteArray & ) ) );
        download->loadList();
    }
    else
    {
        // same document => scroll to anchor
        QString anchor = mirrorList.isEmpty() ? "" : mirrorList.first().fragment();
        if ( !anchor.isEmpty() )
        {
            view->scrollToAnchor( anchor );
        }
        onLoadingFinished( lastUrl, true ); // already loaded => only jump to anchor if required
    }
}

/**
 * @brief HelpBrowser::urlLoaded called, after document has been loaded
 */
void
HtmlWidgetTextView::onUrlLoaded( const QUrl& url, const QByteArray& buffer )
{
    if ( !buffer.isNull() )
    {
        lastUrl = url;
        view->setUrl( url.toString() );
        // Display document
        view->setHtml( QString( buffer ) );

        QString anchor = url.fragment();
        if ( !anchor.isEmpty() )
        {
            {   // workaround for bug #855: if view->scrollToAnchor is called directly, segfault in QTextInlineObject::setWidth(double)
                // because of null pointer reference. After 1st successfull call, the following calls work.
                if ( first )
                {
                    this->anchor = anchor;
                    first        = false;
                    QTimer::singleShot( 1000, this, SLOT( scroll() ) );
                }
                else
                {
                    view->scrollToAnchor( anchor );
                }
            }
            // view->scrollToAnchor( anchor );
        }
        onLoadingFinished( url, true );
    }
    else
    {
        lastUrl = QUrl();
        onLoadingFinished( url, false );
    }
}

void
HtmlWidgetTextView::scroll()
{
    view->scrollToAnchor( anchor );
}

//====================================================================================================================

/**
 * @brief Loads referenced resources
 *
 * This method is called whenever an additional resource (e.g., an image or
 * an CSS style sheet) is referenced from the document. It reimplements the
 * implementation provided by Qt's QTextBrowser class.
 *
 * @param  type  Type of the resource
 * @param  name  Resource URL
 *
 * @return Resource data as QByteArray (encapsulated in a QVariant) on
 *         success, an empty QVariant object otherwise.
 */
QVariant
HtmlTextBrowser::loadResource( int type, const QUrl& name )
{
    Q_UNUSED( type );

    // Sanity check
    if ( !name.isValid() )
    {
        cerr << "Invalid URL: " << name.toString().toStdString().c_str() << endl;
        return QVariant();
    }

    // Determine absolute URL
    QUrl absoluteUrl;
    if ( name.isRelative() )
    {
        absoluteUrl = baseUrl.resolved( name );
    }
    else
    {
        absoluteUrl = name;
    }

    QVariant result;
    if ( absoluteUrl.toString().startsWith( "file://" ) )
    {
        result = QTextBrowser::loadResource( type, absoluteUrl ); // try default resource loader
    }
    if ( result.isNull() )
    {
        // todo: is it possible to do the loading of resources in a thread? QTextBrowser::loadResource expects a result
        result = loadUrlResource( absoluteUrl );
    }

    return result;
}

void
HtmlTextBrowser::setUrl( const QString& url )
{
    baseUrl = url;
}

/** blocking io */
QByteArray
HtmlTextBrowser::loadUrlResource( const QUrl& url )
{
    QByteArray ret;
    // Sanity check
    if ( !url.isValid() )
    {
        return ret;
    }

    QNetworkAccessManager manager;
    QNetworkReply*        response = manager.get( QNetworkRequest( QUrl( url ) ) );
    QEventLoop            event;
    connect( response, SIGNAL( finished() ), &event, SLOT( quit() ) );
    event.exec(); // wait for finished (blocking)
    ret = response->readAll();
    return ret;
}
