/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2017                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/



#ifndef CUBE_TOOLS_MEAN_H
#define CUBE_TOOLS_MEAN_H

#include <QPushButton>
#include <QLabel>
#include <QCheckBox>
#include <QListWidget>
#include "ContextFreePlugin.h"
#include "ContextFreeServices.h"

class CubeMean : public QObject, public cubepluginapi::ContextFreePlugin
{
    Q_OBJECT
    Q_INTERFACES( cubepluginapi::ContextFreePlugin )
#if QT_VERSION >= 0x050000
    Q_PLUGIN_METADATA( IID "CubeMeanPlugin" )
#endif


public:
    // ContextFreePlugin interface
    virtual QString
    name() const;

    virtual void
    opened( cubepluginapi::ContextFreeServices* service );

    virtual void
    closed();

    virtual void
    version(        int& major,
                    int& minor,
                    int& bugfix ) const;

    virtual QString
    getHelpText() const;

private slots:
    void
    selectCubes();
    void
    clearCubes();
    void
    startAction();
    void
    uncheckChoice();

private:
    cubepluginapi::ContextFreeServices* service;

    QPushButton* addCube;
    QPushButton* mean;
    QCheckBox*   reduce;
    QCheckBox*   collapse;
    QListWidget* cubes;
};

#endif // CUBE_TOOLS_H
