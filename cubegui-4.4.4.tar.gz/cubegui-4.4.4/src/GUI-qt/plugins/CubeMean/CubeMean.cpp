/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2017                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"
#include <QtPlugin>
#include <QDebug>
#include <QPushButton>
#include <QVBoxLayout>
#include <QFileDialog>
#include <QApplication>
#include <QStyle>

#include "CubeMean.h"
#include "ContextFreeServices.h"
#include "Cube.h"
#include "algebra4.h"
#include "Globals.h"

using namespace cube;
using namespace cubepluginapi;

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2( CubeMeanPlugin, CubeMean ) // ( PluginName, ClassName )
#endif

void
CubeMean::version( int& major, int& minor, int& bugfix ) const
{
    major  = 1;
    minor  = 0;
    bugfix = 0;
}

QString
CubeMean::name() const
{
    return "Cube Mean";
}

void
CubeMean::opened( ContextFreeServices* service )
{
    this->service = service;

    QWidget* widget = this->service->getWidget();

    QHBoxLayout* layoutOuter = new QHBoxLayout();
    widget->setLayout( layoutOuter );



    QWidget*     inner  = new QWidget();
    QVBoxLayout* layout = new QVBoxLayout( inner );
    layoutOuter->addWidget( inner );
    inner->setSizePolicy( QSizePolicy::Maximum, QSizePolicy::Maximum );

    cubes = new QListWidget();


    QPushButton* addCube   = new QPushButton( "Add cubes" );
    QPushButton* clearList = new QPushButton( "Clear list" );

    mean     = new QPushButton( "Show mean" );
    reduce   = new QCheckBox( "Reduce system dimension" );
    collapse = new QCheckBox( "Collapse system dimension" );
    connect( addCube,                   SIGNAL( clicked() ),    this, SLOT( selectCubes() ) );
    connect( clearList,                   SIGNAL( clicked() ),    this, SLOT( clearCubes() ) );
    connect( mean,                     SIGNAL( clicked() ),    this, SLOT( startAction() ) );
    connect( reduce,                    SIGNAL( pressed() ),    this, SLOT( uncheckChoice() ) );
    connect( collapse,                  SIGNAL( pressed() ),    this, SLOT( uncheckChoice() ) );

    layout->addWidget( cubes );
    layout->addWidget( addCube );
    layout->addWidget( clearList );
    layout->addWidget( mean );

    layout->addWidget( reduce  );
    layout->addWidget( collapse );
    layout->addItem( new QSpacerItem( 0, 10 ) );

    mean->setEnabled( false );
    mean->setStyleSheet( "padding:4px;text-align: center" );
}

void
CubeMean::uncheckChoice()
{
    if ( sender() == reduce )
    {
        collapse->setChecked( false );
    }
    else
    {
        reduce->setChecked( false );
    }
}

void
CubeMean::selectCubes()
{
    QStringList fileNames = QFileDialog::getOpenFileNames( service->getWidget(),
                                                           tr( "Choose a file to open" ),
                                                           "",
                                                           tr( "Cube3/4 files (*cube *cube.gz *.cubex);;Cube4 files (*.cubex);;Cube3 files (*.cube.gz *.cube);;All files (*.*);;All files (*)" ) );
    cubes->addItems( fileNames );
    mean->setEnabled( cubes->count() >= 2 );
}
void
CubeMean::clearCubes()
{
    cubes->clear();
    mean->setEnabled( cubes->count() >= 2 );
}



void
CubeMean::startAction()
{
    cube::Cube*  meand    = new Cube();
    int          num      = cubes->count();
    cube::Cube** cubeList = new Cube*[ num ];
    for ( int i = 0; i < num; i++ )
    {
        cubeList[ i ] = new Cube();
    }
    try
    {
        for ( int i = 0; i < num; i++ )
        {
            QString cube =  cubes->item( i )->text();
            service->setMessage( QString( "Open %1" ).arg( cube ), cubepluginapi::Verbose );
            cubeList[ i ]->openCubeReport( cube.toStdString() );
            service->setMessage( "done", cubepluginapi::Verbose );
        }


        cube4_mean( meand, cubeList, num, reduce->isChecked(), collapse->isChecked() );
    }
    catch ( const RuntimeError& e )
    {
        std::cerr << e.what() << std::endl;
    }

    for ( int i = 0; i < num; i++ )
    {
        delete cubeList[ i ];
    }
    delete[] cubeList;
    service->openCube( meand );

// TODO check whether we need to refresh the current preview or will it be changed by a new one
}

void
CubeMean::closed()
{
}

QString
CubeMean::getHelpText() const
{
    return "This plugin calculates the mean of the given two cube files and displays them.";
}
