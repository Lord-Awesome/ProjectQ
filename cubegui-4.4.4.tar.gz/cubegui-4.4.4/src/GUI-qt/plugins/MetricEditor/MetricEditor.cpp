/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2018                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"
#include <QMessageBox>
#include "MetricEditor.h"
#include "NewDerivatedMetricWidget.h"

using namespace std;
using namespace cubepluginapi;
using namespace cubegui;
using namespace metric_editor;

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2( MetricEditorPlugin, MetricEditorPlugin );
#endif

QString
MetricEditorPlugin::name() const
{
    return "Metric Editor";
}

void
MetricEditorPlugin::version( int& major, int& minor, int& bugfix ) const
{
    major  = 1;
    minor  = 0;
    bugfix = 0;
}


bool
MetricEditorPlugin::cubeOpened( PluginServices* service )
{
    this->service = service;
    connect( service, SIGNAL( contextMenuIsShown( cubepluginapi::TreeType, cubepluginapi::TreeItem* ) ),
             this, SLOT( contextMenuIsShown( cubepluginapi::TreeType, cubepluginapi::TreeItem* ) ) );
    service->addSettingsHandler( this );

    editorWidget = 0;

    return true;
}

void
MetricEditorPlugin::contextMenuIsShown( TreeType type, TreeItem* item )
{
    if ( type != METRICTREE )
    {
        return;
    }
    contextMenuItem = item;

    QAction* action = service->addContextMenuItem( cubegui::METRICTREE, tr( "Edit metric..." ) );
    if ( editorWidget )
    {
        action->setEnabled( false );
    }
    else
    {
        QMenu* editMetricMenu = new QMenu();
        action->setMenu( editMetricMenu );

        QMenu* derivedMetricMenu = editMetricMenu->addMenu( tr( "Create derived metric..." ) );
        editMetricMenu->addMenu( derivedMetricMenu );

        QAction* createDerived, * editDerived, * removeMetric;
        // create an action for creation of the derived metric
        action = new QAction( tr( "as a child" ), this );
        action->setStatusTip( tr( "Creates a derived metric as a child of selected metric." ) );
        connect( action, SIGNAL( triggered() ), this, SLOT( onCreateDerivatedChildMetric() ) );
        action->setWhatsThis( "Creates a derived metric as a child of selected metric. Values of this metric are calculated as an arithmetcal expression of different constants and references to another existing metrics. Derived metrics support only DOUBLE values." );
        derivedMetricMenu->addAction( action );
        createDerived = action;

        // create an action for creation of the derived metric
        action = new QAction( tr( "as a root" ), this );
        action->setStatusTip( tr( "Creates a top level derived metric." ) );
        connect( action, SIGNAL( triggered() ), this, SLOT( onCreateDerivatedRootMetric() ) );
        action->setWhatsThis( "Creates a derived metric as a top level metric. Values of this metric are calculated as an arithmetcal expression of different constants and references to another existing metrics. Derived metrics support only DOUBLE values." );
        derivedMetricMenu->addAction( action );

        // exit the expression of the derived metric
        action = new QAction( tr( "Edit derived metric..." ), this );
        action->setStatusTip( tr( "Shows the online description of the clicked item" ) );
        connect( action, SIGNAL( triggered() ), this, SLOT( onEditDerivatedMetric() ) );
        action->setWhatsThis( "Creates a derived metric as a child of selected metric. Values of this metric are calculated as an arithmetcal expression of different constants and references to another existing metrics. Derived metrics support only DOUBLE values." );
        editMetricMenu->addAction( action );
        editDerived = action;

        // create an action for showing the online metric info of the clicked item,
        // by default disabled, it will be enabled for items for which the url is defined
        action = new QAction( tr( "Remove metric..." ), this );
        action->setStatusTip( tr( "Removes whole subtree of metrics from the cube" ) );
        connect( action, SIGNAL( triggered() ), this, SLOT( onRemoveMetric() ) );
        editMetricMenu->addAction( action );
        action->setWhatsThis( "Removes whole subtree of metrics from the cube" );
        removeMetric = action;

        if ( !item )
        {
            createDerived->setEnabled( false );
            editDerived->setEnabled( false );
            removeMetric->setEnabled( false );
        }
    }
}

void
MetricEditorPlugin::cubeClosed()
{
    foreach( MetricData * metric, userMetrics )
    {
        delete metric;
    }
}

QString
MetricEditorPlugin::getHelpText() const
{
    return "";
}

void
MetricEditorPlugin::onRemoveMetric()
{
    TreeItem*     item     = contextMenuItem;
    cube::Metric* metric   = dynamic_cast<cube::Metric*> ( item->getCubeObject() );
    QString       toRemove = QString::fromStdString( metric->get_uniq_name() );

    QStringList           availableMetricNames;
    vector<cube::Metric*> _metrics = service->getCube()->get_metv();
    for ( vector<cube::Metric*>::iterator m_iter = _metrics.begin(); m_iter != _metrics.end(); ++m_iter )
    {
        availableMetricNames.append( QString::fromStdString( ( *m_iter )->get_uniq_name() ) );
    }

    foreach( MetricData * data, userMetrics )
    {
        if ( !availableMetricNames.contains( data->getUniq_name() ) )
        {
            continue;
        }
        NewDerivatedMetricWidget* tmp      = new NewDerivatedMetricWidget( service, NULL, NULL, NULL, userMetrics );
        QList<QString>            referred = tmp->getReferredMetrics( data );
        delete tmp;
        if ( referred.contains( toRemove ) )
        {
            QMessageBox::critical( service->getParentWidget(), "Error", "Metric is referred by metric " + data->getUniq_name() + "." );
            return;
        }
    }

    if ( item != NULL )
    {
        service->removeMetric( item );
    }
}

void
MetricEditorPlugin::onEditDerivatedMetric()
{
    TreeItem*     item   = contextMenuItem;
    cube::Metric* metric = static_cast<cube::Metric*> ( item->getCubeObject() );

    QWidget* parent = service->getParentWidget();
    editorWidget = new NewDerivatedMetricWidget( service, metric, NULL, parent, userMetrics );
    editorWidget->setVisible( true );
    connect( editorWidget, SIGNAL( accepted() ), this, SLOT( updateMetricFinished() ) );
    connect( editorWidget, SIGNAL( rejected() ), this, SLOT( metricEditorCancelled() ) );
}

void
MetricEditorPlugin::metricEditorCancelled()
{
    editorWidget->disconnect();
    editorWidget->deleteLater();
    editorWidget = 0;
}

void
MetricEditorPlugin::updateMetricFinished()
{
    editorWidget->disconnect();
    service->updateMetric( contextMenuItem );
    editorWidget->deleteLater();
    editorWidget = 0;
}

void
MetricEditorPlugin::addMetricFinished()
{
    editorWidget->disconnect();
    TreeItem*     item      = contextMenuItem;
    cube::Metric* newMetric = editorWidget->get_created_metric();
    if ( newMetric != NULL )                          // add metric to the metric tree only, if one was created
    {
        if ( item == NULL || isChildMetric == false ) // create top level metric
        {
            service->addMetric( newMetric );
        }
        else
        {
            service->addMetric( newMetric, item );
        }
    }

    editorWidget->deleteLater();
    editorWidget = 0;
}

void
MetricEditorPlugin::createDerivatedMetric( bool asChild )
{
    isChildMetric = asChild;
    TreeItem*     item   = contextMenuItem;
    cube::Metric* metric = NULL;
    if ( item != NULL && isChildMetric )
    {
        metric = static_cast<cube::Metric*> ( item->getCubeObject() );
    }

    QWidget* parent = service->getParentWidget();

    editorWidget = new NewDerivatedMetricWidget( service, NULL, metric, parent, userMetrics );
    editorWidget->setVisible( true );

    connect( editorWidget, SIGNAL( accepted() ), this, SLOT( addMetricFinished() ) );
    connect( editorWidget, SIGNAL( rejected() ), this, SLOT( metricEditorCancelled() ) );
}

void
MetricEditorPlugin::onCreateDerivatedChildMetric()
{
    createDerivatedMetric( true );
}

void
MetricEditorPlugin::onCreateDerivatedRootMetric()
{
    createDerivatedMetric( false );
}

void
MetricEditorPlugin::loadGlobalOnlySettings( QSettings& settings )
{
    userMetrics.clear();
    int size = settings.beginReadArray( "userMetrics" );
    for ( int i = 0; i < size; ++i )
    {
        settings.setArrayIndex( i );
        MetricData* data = new MetricData( service->getCube(), NULL );
        data->setCubePL( settings.value( "metric" ).toString() );
        userMetrics.append( data );
    }
    settings.endArray();
}

void
MetricEditorPlugin::saveGlobalOnlySettings( QSettings& settings )
{
    settings.beginWriteArray( "userMetrics" );
    for ( int i = 0; i < userMetrics.size(); ++i )
    {
        settings.setArrayIndex( i );
        settings.setValue( "metric", userMetrics.at( i )->toString() );
    }
    settings.endArray();
}
