/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2017                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include "config.h"
#include <QtPlugin>
#include <QDebug>
#include <QPushButton>
#include <QVBoxLayout>
#include <QFileDialog>
#include <QDirIterator>
#include <QFileDialog>
#include <QFileInfo>
#include <QStringList>
#include <QApplication>
#include <QStyle>

#include "CubeMerge.h"
#include "ContextFreeServices.h"
#include "Cube.h"
#include "algebra4.h"
#include "Globals.h"

using namespace cube;
using namespace cubepluginapi;

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2( CubeMergePlugin, CubeMerge ) // ( PluginName, ClassName )
#endif

CubeMerge::CubeMerge()
{
    profile_regex = QRegExp( "profile" );
}

void
CubeMerge::version( int& major, int& minor, int& bugfix ) const
{
    major  = 1;
    minor  = 0;
    bugfix = 0;
}

QString
CubeMerge::name() const
{
    return "Cube Merge";
}

void
CubeMerge::opened( ContextFreeServices* service )
{
    this->service = service;

    QWidget* widget = this->service->getWidget();

    QHBoxLayout* layoutOuter = new QHBoxLayout();
    widget->setLayout( layoutOuter );



    QWidget*     inner  = new QWidget();
    QVBoxLayout* layout = new QVBoxLayout( inner );
    layoutOuter->addWidget( inner );
    inner->setSizePolicy( QSizePolicy::Maximum, QSizePolicy::Maximum );

    cubes = new QListWidget();


    QPushButton* addCube   = new QPushButton( "Add cubes" );
    QPushButton* clearList = new QPushButton( "Clear list" );

    merge    = new QPushButton( "Show merge" );
    reduce   = new QCheckBox( "Reduce system dimension" );
    collapse = new QCheckBox( "Collapse system dimension" );
    connect( addCube,                   SIGNAL( clicked() ),    this, SLOT( selectProfilesCubes() ) );
    connect( clearList,                   SIGNAL( clicked() ),    this, SLOT( clearCubes() ) );
    connect( merge,                     SIGNAL( clicked() ),    this, SLOT( startAction() ) );
    connect( reduce,                    SIGNAL( pressed() ),    this, SLOT( uncheckChoice() ) );
    connect( collapse,                  SIGNAL( pressed() ),    this, SLOT( uncheckChoice() ) );

    layout->addWidget( cubes );
    layout->addWidget( addCube );
    layout->addWidget( clearList );
    layout->addWidget( merge );

    layout->addWidget( reduce  );
    layout->addWidget( collapse );
    layout->addItem( new QSpacerItem( 0, 10 ) );

    merge->setEnabled( false );
    merge->setStyleSheet( "padding:4px;text-align: center" );

    if ( !args.isEmpty() )
    {
        selectCubes( args.takeFirst(), QRegExp( "profile" ) );
        startAction();
    }
}


void
CubeMerge::uncheckChoice()
{
    if ( sender() == reduce )
    {
        collapse->setChecked( false );
    }
    else
    {
        reduce->setChecked( false );
    }
}




void
CubeMerge::selectProfilesCubes()
{
    QStringList experiments;
    QString     dir = QFileDialog::getExistingDirectory( service->getWidget(), tr( "Open Score-P Experiements " ),
                                                         "",
                                                         QFileDialog::ShowDirsOnly
                                                         | QFileDialog::DontResolveSymlinks );
    selectCubes( dir, profile_regex );
}


void
CubeMerge::selectCubes( const QString& dir, const QRegExp& name_pattern )
{
    QStringList  experiments;
    QDirIterator it( dir, QDirIterator::Subdirectories );
    while ( it.hasNext() )
    {
        QString   file = it.next();
        QFileInfo fi( file );
        QString   name   = fi.baseName();
        QString   suffix = fi.completeSuffix();
        if ( ( suffix.compare( "cubex" ) == 0 ) && ( name.contains( name_pattern ) ) )
        {
            experiments << file;
        }
    }
    experiments.sort();
    cubes->addItems( experiments );
    merge->setEnabled( cubes->count() >= 2 );
}
void
CubeMerge::clearCubes()
{
    cubes->clear();
    merge->setEnabled( cubes->count() >= 2 );
}



void
CubeMerge::startAction()
{
    cube::Cube*  merged   = new Cube();
    int          num      = cubes->count();
    cube::Cube** cubeList = new Cube*[ num ];
    for ( int i = 0; i < num; i++ )
    {
        cubeList[ i ] = new Cube();
    }
    try
    {
        for ( int i = 0; i < num; i++ )
        {
            QString cube =  cubes->item( i )->text();
            service->setMessage( QString( "Open %1" ).arg( cube ), cubepluginapi::Verbose );
            cubeList[ i ]->openCubeReport( cube.toStdString() );
            service->setMessage( "done", cubepluginapi::Verbose );
        }


        cube4_merge( merged, cubeList, num, reduce->isChecked(), collapse->isChecked() );
    }
    catch ( const RuntimeError& e )
    {
        std::cerr << e.what() << std::endl;
    }

    for ( int i = 0; i < num; i++ )
    {
        delete cubeList[ i ];
    }
    delete[] cubeList;
    service->openCube( merged );

// TODO check whether we need to refresh the current preview or will it be changed by a new one
}

void
CubeMerge::closed()
{
}

QString
CubeMerge::getHelpText() const
{
    return "This plugin calculates the merge beetween the given cube files and displays result.";
}
