/****************************************************************************
**  CUBE        http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2018                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#ifndef CUBE_TOOLS_MERGE_H
#define CUBE_TOOLS_MERGE_H

#include <QPushButton>
#include <QLabel>
#include <QCheckBox>
#include <QRegExp>
#include <QListWidget>
#include "ContextFreePlugin.h"
#include "ContextFreeServices.h"




class CubeMerge : public QObject, public cubepluginapi::ContextFreePlugin
{
    Q_OBJECT
    Q_INTERFACES( cubepluginapi::ContextFreePlugin )
#if QT_VERSION >= 0x050000
    Q_PLUGIN_METADATA( IID "CubeMergePlugin" )
#endif


public:

    CubeMerge();

    // ContextFreePlugin interface
    virtual QString
    name() const;

    virtual void
    opened( cubepluginapi::ContextFreeServices* service );

    virtual void
    closed();

    virtual void
    version( int& major,
             int& minor,
             int& bugfix ) const;

    virtual QString
    getHelpText() const;

    virtual void
    setArguments( const QStringList& args )
    {
        this->args = args;
    }

private slots:
    void
    selectProfilesCubes();
    void
    selectCubes( const QString& path,
                 const QRegExp&   );
    void
    clearCubes();
    void
    startAction();
    void
    uncheckChoice();

private:
    cubepluginapi::ContextFreeServices* service;
    QStringList                         args;

    QRegExp      profile_regex;
    QPushButton* addCube;
    QPushButton* merge;
    QCheckBox*   reduce;
    QCheckBox*   collapse;
    QListWidget* cubes;
};

#endif // CUBE_TOOLS_H
