#ifndef LIBWRAP_H
#define LIBWRAP_H

/*
 * You need to  put any needed #include statements to successfully compile a mini program against the
 * to-be-wrapped library in this file.
 *
 * After you are finished, start editing the `main.c` file.
 */

#endif /* LIBWRAP_H */
