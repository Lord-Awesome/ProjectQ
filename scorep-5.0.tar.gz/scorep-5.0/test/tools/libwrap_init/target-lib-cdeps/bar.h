#ifdef __cplusplus
extern "C"
{
#endif

void
fn_1( void );
void
fn_2( void );

#ifdef __cplusplus
};
#endif
